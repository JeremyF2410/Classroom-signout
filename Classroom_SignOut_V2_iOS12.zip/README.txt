CLASSROOM SIGN-OUT V2

Designed for iPad mini 2 running iOS 12.5.8.

GITHUB PAGES
1. Create a public GitHub repository named classroom-signout.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Choose Deploy from a branch.
5. Select main and /(root), then Save.
6. Open the published address in Safari on the iPad.
7. Use Share > Add to Home Screen.
8. Use Guided Access to lock the iPad to the app.

TEACHER ACCESS
Tap the title 5 times quickly.
Default PIN: 1234

IMPORTANT
Do not use Private Browsing.
Do not clear Safari website data if you need to keep history.
Student names and history stay on the iPad in local storage.
